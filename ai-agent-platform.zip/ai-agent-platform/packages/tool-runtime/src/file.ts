import fs from "fs/promises";

export class FileTool {
  async read(path: string) {
    return await fs.readFile(path, "utf-8");
  }

  async write(path: string, content: string) {
    await fs.writeFile(path, content);
    return true;
  }
}

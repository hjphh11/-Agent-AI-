import { ChatOpenAI } from "@langchain/openai";
import { HumanMessage, SystemMessage } from "@langchain/core/messages";

export class DevAgent {
  private llm;

  constructor() {
    this.llm = new ChatOpenAI({
      model: "gpt-4.1",
      temperature: 0.2,
      apiKey: process.env.OPENAI_API_KEY,
    });
  }

  async run(prompt: string) {
    const response = await this.llm.invoke([
      new SystemMessage(`
You are an autonomous software engineer.
You can write code, debug, execute shell, and modify files.
      `),
      new HumanMessage(prompt),
    ]);

    return response.content;
  }
}

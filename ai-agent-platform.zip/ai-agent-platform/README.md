# AI Agent Platform

创业级 AI Agent 自动化开发平台

## Features

- Multi Agent
- AI Coding
- Browser Automation
- Docker Sandbox
- Workflow Engine
- LangGraph
- MCP Tools

## Stack

- Next.js
- NestJS
- LangChain
- PostgreSQL
- Redis
- Docker

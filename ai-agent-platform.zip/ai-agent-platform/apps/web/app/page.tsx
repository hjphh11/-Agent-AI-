"use client";

import { useState } from "react";

export default function HomePage() {
  const [prompt, setPrompt] = useState("");
  const [result, setResult] = useState("");

  async function submit() {
    const res = await fetch("http://localhost:3001/task", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ prompt }),
    });

    const data = await res.json();
    setResult(JSON.stringify(data, null, 2));
  }

  return (
    <div className="p-10 space-y-4">
      <h1 className="text-3xl font-bold">
        AI Agent Platform
      </h1>

      <textarea
        className="border p-4 w-full h-40"
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />

      <button
        className="bg-black text-white px-6 py-3"
        onClick={submit}
      >
        Execute
      </button>

      <pre>{result}</pre>
    </div>
  );
}
